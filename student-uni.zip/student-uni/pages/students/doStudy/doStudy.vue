<template>
	<view>
		<!-- 头部导航 -->
		<view class="example-body"><uni-nav-bar left-icon="arrowleft" left-text="返回" @clickLeft="back" :rightText="show_choose_offline_file? '已缓存': '离线缓存'" @clickRight="navRightClick" /></view>

		<!-- 左侧抽屉 -->
		<uni-drawer :visible="show_left_drawer">
			<button type="primary" @click="show_left_drawer = false">关闭</button>

			<view class="">asdad</view>
		</uni-drawer>

		<!-- 中间内容 -->
		<view v-for="(m, mi) in list_modules" :key="mi">
			<uni-section :title="m.ModuleName" type="line"></uni-section>

			<!-- thumb="https://img-cdn-qiniu.dcloud.net.cn/new-page/uni.png" -->
			<uni-list>
				<uni-list-item v-for="(res, res_i) in m.CoResourceView" :key="res_i">
					
					<!-- 如果是正常模式，直接跳转阅读页面 -->
					<view class="" @click="read(res)" v-if="!show_choose_offline_file">						
						{{ res.ResourceName }}
					</view>
					
					<!-- 如果是选择离线文件模式，选中需要缓存的文件
					 -->
					 <view v-if="show_choose_offline_file" @click="res.isOfflineSaved=!res.isOfflineSaved">
					 	<radio :checked="res.isOfflineSaved"></radio>
					 	{{ res.ResourceName }}
					 </view>
					 
				</uni-list-item>
			</uni-list>
		</view>
		
		
		
		<!-- 如过是选择文件缓存模式，显示退出按钮 -->
		<button style="margin: 30rpx;" type="warn" v-if="show_choose_offline_file" @click="saveFilesToOffline()">确定</button>		
		<button style="margin: 30rpx;" type="primary" v-if="show_choose_offline_file" @click="show_choose_offline_file=false">退出</button>

		<!-- 右侧抽屉 -->
	</view>
</template>

<script>
import uniNavBar from '@/components/uni-nav-bar/uni-nav-bar.vue';
import uniDrawer from '@/components/uni-drawer/uni-drawer.vue';
import mixTree from '@/components/mix-tree/mix-tree';
import uniSection from '@/components/uni-section/uni-section.vue';
import uniList from '@/components/uni-list/uni-list.vue';
import uniListItem from '@/components/uni-list-item/uni-list-item.vue';
export default {
	components: {
		uniDrawer,
		mixTree,
		uniSection,
		uniList,
		uniListItem,
		uniNavBar
	},
	data() {
		return {
			// 是否处于选择离线文件模式
			show_choose_offline_file:false,
			show_left_drawer: false,
			extraIcon1: {
				color: '#007aff',
				size: '22',
				type: 'gear-filled'
			},
			extraIcon2: {
				color: '#4cd964',
				size: '22',
				type: 'image'
			},
			list_modules: []
		};
	},
	created() {
		this.reloadModules();
	},
	methods: {
		// 导航栏右侧点击
		navRightClick(){
			let that=this
			if(that.show_choose_offline_file){
				// 如过显示的是已缓存的视频,则重定向到已缓存的视频
				uni.redirectTo({
					url:"/pages/students/offlineFiles/offlineFiles"
				})
			}else{
				// 如过是正常显示,则显示选择那些文件需要缓存
				that.show_choose_offline_file=true
			}
			
		},
		// 将文件存储到本地
		 saveFilesToOffline : function(){
			
			let that=this
			uni.showToast({
				title:"正在缓存，请稍后。"
			})
			
			// 先打开保存文件和文件id映射关系
			// let m=uni.
			
			
			// 先查找已经缓存过的文件
			uni.getSavedFileList({
				success(r) {
					
				
					let file_list=r.fileList || []
					console.log("已缓存文件：",file_list)
					
					let _saved_file_ids=file_list.map(e=>{return e.filePath}).join(",")
					
					// 待下载的文件集合
					let _file_wait_to_download=[]					
					that.list_modules.forEach(m=>{
						m.CoResourceView.forEach(r=>{
							if(r.isOfflineSaved){
								// 从选中文件中筛选出未下载过的，添加到集合中
								if(_saved_file_ids.indexOf(r.ResourceCode)==-1){
									
									_file_wait_to_download.push(r)
									
									
								}
							}
						})
					})
					
					
					
					console.log("需要下载文件集合：" ,_file_wait_to_download)
					
					// 下载每一个文件
					_file_wait_to_download.forEach(e=>{
						let r_download= uni.downloadFile({
							url:"https://ve-1256163091.cos.ap-beijing.myqcloud.com/0038938a-4a43-491d-be82-e8d74633f93d.doc"
						})
						
						console.log(r_download)
						
						
					})
					// uni.downloadFile({
					// 	url:'https://ve-1256163091.cos.ap-beijing.myqcloud.com/0038938a-4a43-491d-be82-e8d74633f93d.doc',
					// 		success: (r_download) => {
					// 			console.log('文件下载到临时目录完成',r_download)
								
					// 			// 将文件保存到本地
					// 			uni.saveFile({
					// 				tempFilePath:r_download.tempFilePath,
					// 				success: (r_save) => {
					// 					console.log('文件保存完毕',r_save)
										
					// 					let _saved_files_new=uni.getSavedFileList({
					// 						success: (r_load_saved) => {
					// 							console.log("从新获取filelist:",r_load_saved)
					// 						}
					// 					})
										
					// 				}
					// 			})
					// 		}
					// })
													
					
				}
			})
			
			
			
			
			
			
		},
		// 尝试离线缓存
		offlineSave(t, item) {
			console.log('offlineSave', arguments);
			// 如果是询问是否下载
			if (t == 'ask') {
				uni.showModal({
					title: '确认缓存文件：' + item.ResourceName + '吗？',
					success(e) {
						if (e.confirm) {
							// 如果确认缓存
							console.log('开始缓存', e);
							uni.saveFile({
								tempFilePath: '/temp',
								success(r) {
									let savedFilePath = r.savedFilePath;
									uni.showToast({
										title: `文件存储在：${savedFilePath}`
									});
								}
							});
						}
					},
					complete() {}
				});
			}
		},

		// 查看离线资源
		goToOfflineResource() {
			uni.redirectTo({
				url: '/pages/students/offlineResource/offlineResource'
			});
		},
		// 返回
		back() {
			uni.redirectTo({
				url: '/pages/students/course/courseDetail/courseDetail'
			});
		},
		read(item) {
			// 如过是知网资源,直接跳转
			if (item.IsCNKI) {
				uni.navigateTo({
					url: item.Link
				});
			}
			// 如果是视频
			if (item.ResourceType == 'video'){
				uni.redirectTo({
					url:"../read/read?resType=video&resUrl=http://1256163091.vod2.myqcloud.com/7d0c14a4vodcq1256163091/aa0e30175285890795940545382/f1TJemEnRMwA.mp4"
				})
			}

			// 如果是文档阅读
			if (item.ResourceType == 'wordprocessing') {
				uni.showLoading({
					mask: true,
					title: '正在获取文件，请稍候...'
				});

				uni.downloadFile({
					header: {
						Origin: '*',
						'Access-Control-Allow-Origin': '*',
						'Access-Control-Request-Method': '*',
						'Access-Control-Request-Headers': '*',
						'Access-Control-Allow-Credentials': false
					},
					url: 'https://ve-1256163091.cos.ap-beijing.myqcloud.com/0038938a-4a43-491d-be82-e8d74633f93d.doc',
					success: function(res) {
						var filePath = res.tempFilePath;
						uni.openDocument({
							filePath: filePath,
							success: function(res) {
								console.log('打开文档成功');
							}
						});
					},
					complete: function() {
						uni.hideLoading();
					}
				});
			}

			// 如果是pdf阅读
			if (item.ResourceType == 'pdf') {
				uni.showLoading({
					mask: true,
					title: '正在获取文件，请稍候...'
				});
				uni.downloadFile({
					header: {
						Origin: '*',
						'Access-Control-Allow-Origin': '*',
						'Access-Control-Request-Method': '*',
						'Access-Control-Request-Headers': '*',
						'Access-Control-Allow-Credentials': false
					},
					url: 'https://ve-1256163091.cos.ap-beijing.myqcloud.com/000483d6-3764-4c1a-a170-f3be6a2744ac.pdf',
					success: function(res) {
						var filePath = res.tempFilePath;
						uni.openDocument({
							filePath: filePath,
							success: function(res) {
								console.log('打开文档成功');
							}
						});
					},

					complete: function() {
						uni.hideLoading();
					}
				});
			}
		},
		reloadModules() {
			let r = {
				Code: 200,
				Data: [
					{
						ModuleCode: '2f7bd5d8-f681-4c09-8e92-bd893ab75754',
						ModuleName: '教学设计',
						CourseCode: 'a27e86db-4661-4d5e-8fc4-48b25bdd638b',
						ModuleType: '资源列表',
						UserId: '0f79635f-80c0-4a6e-a634-30b925a9413a',
						ShowNo: 1,
						OwnerCode: 'f32950c9-9576-469f-b2c4-b001a2f68be0',
						DownloadFlag: 0,
						DiscussStatus: 0,
						ReviewFlag: 0,
						StudentFlag: 0,
						ReviewStatus: 0,
						ReviewMark: null,
						WenBenFlag: 0,
						KongFlag: 0,
						LianJieFlag: 0,
						TuPianFlag: 0,
						KeJianFlag: 0,
						ShiPinFlag: 0,
						UserName: null,
						PostTime: '2019-05-10T16:02:02Z',
						ExtOne: 0,
						ExtTwo: 0,
						CoResourceView: [
							{
								ResourceCode: 'c2973ada-107b-4e57-9dc9-644458fee8ad',
								ResourceName: '异构文本数据转换中XML解析方法对比研究',
								ResourceType: 'thirdparty',
								Content: 'odata',
								DownloadCode: 'JSJC20190814002|CAPJ2019|Literature',
								XmlCode: 'Literature',
								XMLFragmentationCode: null,
								ModuleCode: '2f7bd5d8-f681-4c09-8e92-bd893ab75754',
								ModuleName: null,
								ExtType: null,
								CourseCode: 'a27e86db-4661-4d5e-8fc4-48b25bdd638b',
								UserId: '0f79635f-80c0-4a6e-a634-30b925a9413a',
								RealName: '何卓桁;刘志勇;李璐;李长明;张琳',
								UserName: null,
								SubmitUserName: '熊凡',
								DiscussStatus: 0,
								DiscussId: null,
								LiveDiscussLink: null,
								LiveDiscussStatus: 0,
								LiveDiscussId: null,
								DiscussLink: null,
								ReviewFlag: 0,
								ReviewFlagHanZi: null,
								ReviewMark: null,
								PostTime: '2019-08-19T11:24:54Z',
								DownloadLink: null,
								FileType: 0,
								CatalogHtml: null,
								Extension: null,
								ReviewFlagShu: 0,
								ZiYuanZongShu: 0,
								ResourceTypeShu: 0,
								LiteratureID: null,
								IsPublic: 0,
								MiniDiscussList: null,
								Exercise: null,
								CataLogName: null,
								Stage: null,
								SubjectName: null,
								CourseVersion: null,
								CourseName: null,
								IsMy: 0,
								IsCNKI: 1,
								AddSource: 1,
								Link: 'http://kns.cnki.net/KCMS/detail/detail.aspx?dbcode=CAPJ&dbname=CAPJLAST&filename=JSJC20190814002',
								FileSize: null,
								IsTencent: 0,
								ShowNo: 3,
								InitialResourceName: null,
								HasArranged: false,
								IsRead: 1,
								IsDownLoad: 0,
								Synthesis: 2
							},
							{
								ResourceCode: 'c5759710-db79-4c95-8e65-c05b0a2c8468',
								ResourceName: '糖尿病医院知识资源总库总体介绍190608.docx',
								ResourceType: 'wordprocessing',
								Content: null,
								DownloadCode: '42650aab-a7b4-46e3-9739-32946912a5ac.docx',
								XmlCode: '42650aab-a7b4-46e3-9739-32946912a5ac.docx|',
								XMLFragmentationCode: null,
								ModuleCode: '2f7bd5d8-f681-4c09-8e92-bd893ab75754',
								ModuleName: null,
								ExtType: null,
								CourseCode: 'a27e86db-4661-4d5e-8fc4-48b25bdd638b',
								UserId: '0f79635f-80c0-4a6e-a634-30b925a9413a',
								RealName: '熊凡',
								UserName: null,
								SubmitUserName: '熊凡',
								DiscussStatus: 0,
								DiscussId: null,
								LiveDiscussLink: null,
								LiveDiscussStatus: 0,
								LiveDiscussId: null,
								DiscussLink: null,
								ReviewFlag: 0,
								ReviewFlagHanZi: null,
								ReviewMark: null,
								PostTime: '2019-07-29T09:42:37Z',
								DownloadLink: null,
								FileType: 0,
								CatalogHtml: null,
								Extension: null,
								ReviewFlagShu: 0,
								ZiYuanZongShu: 0,
								ResourceTypeShu: 0,
								LiteratureID: null,
								IsPublic: 0,
								MiniDiscussList: null,
								Exercise: null,
								CataLogName: null,
								Stage: null,
								SubjectName: null,
								CourseVersion: null,
								CourseName: null,
								IsMy: 0,
								IsCNKI: 0,
								AddSource: 0,
								Link: null,
								FileSize: '75201',
								IsTencent: 0,
								ShowNo: 3,
								InitialResourceName: '糖尿病医院知识资源总库总体介绍190608.docx',
								HasArranged: false,
								IsRead: 1,
								IsDownLoad: 0,
								Synthesis: 0
							},
							{
								ResourceCode: 'f7a9d14b-0e60-4649-bdb1-45e79d3e27db',
								ResourceName: '1564378890148.doc',
								ResourceType: 'wordprocessing',
								Content: null,
								DownloadCode: '495ba535-f002-4056-97e8-ac5383b7803b.doc',
								XmlCode: '495ba535-f002-4056-97e8-ac5383b7803b.doc|',
								XMLFragmentationCode: null,
								ModuleCode: '2f7bd5d8-f681-4c09-8e92-bd893ab75754',
								ModuleName: null,
								ExtType: null,
								CourseCode: 'a27e86db-4661-4d5e-8fc4-48b25bdd638b',
								UserId: '0f79635f-80c0-4a6e-a634-30b925a9413a',
								RealName: '熊凡',
								UserName: null,
								SubmitUserName: '熊凡',
								DiscussStatus: 0,
								DiscussId: null,
								LiveDiscussLink: null,
								LiveDiscussStatus: 0,
								LiveDiscussId: null,
								DiscussLink: null,
								ReviewFlag: 0,
								ReviewFlagHanZi: null,
								ReviewMark: null,
								PostTime: '2019-08-26T14:27:57Z',
								DownloadLink: null,
								FileType: 0,
								CatalogHtml: null,
								Extension: null,
								ReviewFlagShu: 0,
								ZiYuanZongShu: 0,
								ResourceTypeShu: 0,
								LiteratureID: null,
								IsPublic: 0,
								MiniDiscussList: null,
								Exercise: null,
								CataLogName: null,
								Stage: null,
								SubjectName: null,
								CourseVersion: null,
								CourseName: null,
								IsMy: 0,
								IsCNKI: 0,
								AddSource: 0,
								Link: null,
								FileSize: '505344',
								IsTencent: 0,
								ShowNo: 4,
								InitialResourceName: '1564378890148.doc',
								HasArranged: false,
								IsRead: 1,
								IsDownLoad: 0,
								Synthesis: 0
							},
							{
								ResourceCode: '99c12803-756a-4d09-9227-5fe0450b2287',
								ResourceName: '《汽车发动机机油的更换》教学设计方案.docx',
								ResourceType: 'wordprocessing',
								Content: null,
								DownloadCode: 'af7b58aa-49d0-4cff-b71a-be509b80008b.docx',
								XmlCode: 'af7b58aa-49d0-4cff-b71a-be509b80008b.docx|',
								XMLFragmentationCode: null,
								ModuleCode: '2f7bd5d8-f681-4c09-8e92-bd893ab75754',
								ModuleName: null,
								ExtType: null,
								CourseCode: 'a27e86db-4661-4d5e-8fc4-48b25bdd638b',
								UserId: '0f79635f-80c0-4a6e-a634-30b925a9413a',
								RealName: '熊凡',
								UserName: null,
								SubmitUserName: '熊凡',
								DiscussStatus: 0,
								DiscussId: null,
								LiveDiscussLink: null,
								LiveDiscussStatus: 0,
								LiveDiscussId: null,
								DiscussLink: null,
								ReviewFlag: 0,
								ReviewFlagHanZi: null,
								ReviewMark: null,
								PostTime: '2019-09-20T11:16:19Z',
								DownloadLink: null,
								FileType: 0,
								CatalogHtml: null,
								Extension: null,
								ReviewFlagShu: 0,
								ZiYuanZongShu: 0,
								ResourceTypeShu: 0,
								LiteratureID: null,
								IsPublic: 0,
								MiniDiscussList: null,
								Exercise: null,
								CataLogName: null,
								Stage: null,
								SubjectName: null,
								CourseVersion: null,
								CourseName: null,
								IsMy: 0,
								IsCNKI: 0,
								AddSource: 0,
								Link: null,
								FileSize: '1791089',
								IsTencent: 0,
								ShowNo: 5,
								InitialResourceName: '《汽车发动机机油的更换》教学设计方案.docx',
								HasArranged: false,
								IsRead: 1,
								IsDownLoad: 0,
								Synthesis: 0
							}
						],
						CoHomeWorks: null,
						Content: null,
						ResourceCode: null,
						ContentFlag: 0,
						HomeworkSubmitFlag: 0,
						Introduction: null,
						StudentWork: null,
						CanDelete: 0,
						ResourceCount: 0,
						PModuleCode: null
					},
					{
						ModuleCode: 'b5b6dfac-feed-43f9-b386-ea5d1890f070',
						ModuleName: '课程内容',
						CourseCode: 'a27e86db-4661-4d5e-8fc4-48b25bdd638b',
						ModuleType: '教学设计类',
						UserId: '0f79635f-80c0-4a6e-a634-30b925a9413a',
						ShowNo: 2,
						OwnerCode: 'f32950c9-9576-469f-b2c4-b001a2f68be0',
						DownloadFlag: 0,
						DiscussStatus: 0,
						ReviewFlag: 0,
						StudentFlag: 0,
						ReviewStatus: 0,
						ReviewMark: null,
						WenBenFlag: 0,
						KongFlag: 0,
						LianJieFlag: 0,
						TuPianFlag: 0,
						KeJianFlag: 0,
						ShiPinFlag: 0,
						UserName: null,
						PostTime: '2019-05-10T16:02:02Z',
						ExtOne: 0,
						ExtTwo: 0,
						CoResourceView: [
							{
								ResourceCode: '8e0012fe-279a-469f-8f08-5f88236da6e3',
								ResourceName: '测试视频.mp4',
								ResourceType: 'video',
								Content:
									'<p style="font-size:16px;font-family:微软雅黑;text-align:center"><img data_source="0dfa748d-9b82-45b9-8749-7fb8f7984f5a" src="http://ve.cnki.net/coeduApi/api/File/ShowFile?filecode=44806dc7-ecaf-4c94-8855-d5701347e826.png" data-meta="mUg7d10mz_a1A_0tUDKE6vZaOc62P9bi9e41QqAy9mrenbgTkNh5apjh69jwXjyzKR3UDAcy4U7S1mGzs9ZtdRtorPqHw7QT3CjUlpyXy9eRwFU_a1A_lTjulN9bL4EZF47bp4HygrBjFyA83zLo5IirsYK6Qg0pMJ_a1A_JZcG6R_a1A_gpCYd75cVAUjhQRBsgrcLF0wywrtHQ4dUw3GzfKnp4vrb0M3S6i3MIw3T2AUv813nzESNd24liSk6senwYpTevsCQc84U0HZFkcjlI9aTkjQ_a1A_0JmfPKGO0yxcXGW_c3C_CqRHuoaC9ie6U00Xz0jv2OpMTN729ZLeyPxDMBMnsJl5QYzxHi4I3ZdzgXwQr5sCU5AZ910z84veJxVTVy6QT23DNufofnVuuRtC95_c3C_5PW6nJ68crFLcBRw_b2B__b2B_" style="max-width:100%;cursor:pointer;" role="999" class="video_fake_img" data-nopop="1" onclick="parent.weditor.open(this)" width="360" height="200"/></p><p style="font-size:16px;font-family:微软雅黑;text-align:center">gs</p><p style="font-size:16px;font-family:微软雅黑;"><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span></p><p style="font-size:16px;font-family:微软雅黑;"><span></span></p><p style="font-size:16px;font-family:微软雅黑;text-align:center"><img data_source="1272b2ac-b389-4be5-81b2-ae0d20ad5884" src="http://ve.cnki.net/coeduApi/api/File/ShowFile?filecode=74c31d16-bf3b-4292-a38e-02efb98dc203.png" data-meta="mUg7d10mz_a1A_0tUDKE6vZaOYTUSZN_a1A_LMZ3VE4f41ngXQgad_c3C_Mqqrr8_c3C_z_a1A_nEjxqwRPM8wn5_a1A_k401PGweGg5DqsMqTJRYKKesNGX8HDH73_a1A_iNqj42rbaZG9PjxjqaVq_a1A_FajOw2tftSti_c3C_iP1_a1A_c7FAEdw8FpXLcwsZaHGRBXZvYvHSIgFsOQWrwFxlMGQFTPX34yiGW9Ms7FO5DIfjMjgwx178ZHo1KrVCqlTDOFFwRibTZjwihtxMSuZMiBRG7nVcZz8tAwYROOJ3aKKSRah5v_c3C_jYeDRj5UL2gEBbpKrpEaYgZlVEcXbv9kfqHj6D3rdOC2CEX7PHxG0vkbbLuNtNvA5EPiLUI8oTwV7NE_a1A_DFv2KIYRK_a1A_rpSLMvjKaTJxbwnxa5tr3Qhpdmrcqg5D4e2ENxp1w_b2B__b2B_" style="max-width:100%;cursor:pointer;" role="999" class="video_fake_img" data-nopop="1" onclick="parent.weditor.open(this)" width="360" height="200"/></p><p style="font-size:16px;font-family:微软雅黑;text-align:center">dh</p><p style="font-size:16px;font-family:微软雅黑;"><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span><span>撒奥奥无多</span></p><p style="font-size:16px;font-family:微软雅黑;text-align:center"><img data_source="3668e1b7-62ee-4116-bea2-0bf4ff739d00" src="http://ve.cnki.net/coeduApi/api/File/ShowFile?filecode=eefcaf25-38b9-4643-9739-5890d77098ab.png" data-meta="odMfJdxVYWhuM5is3edhmclc37D0JMidyV173HEOjPt8gEQOSt4Ojr9dM6LTzmkR_c3C_HTQ_a1A_3dQ_c3C_XtRWyJvo9qno9j1cNtneQaowlhtBX6lA8gpADhkLTzXR4oEg1BsprShiRrArb2fA_a1A_mwP7AcOukUZNfxbGssgrgMPkTjWwPXm7lSaXQ8l7I59qlIU8RBCXu81D9hzA_c3C_LApACk0LN1uI_a1A_7_c3C_gqySuGiNftcxcYe12YfsCRrmvmp6l96c_c3C_rInIz1LEfq4jvc4uPW3SkBK1WMK6wiwqG67s2T3pTxxGST8xy4yOI7goSFdX94UpyG8TLi5dvSPhsyqxZg1k_a1A_jcVQeT8cjNqd0AUXQACAShqT3bQgFqU_b2B_" style="max-width:100%;cursor:pointer;" role="999" class="video_fake_img" data-nopop="1" onclick="parent.weditor.open(this)" width="360" height="200"/></p><p style="font-size:16px;font-family:微软雅黑;text-align:center">数学广角-抽屉原则-分棋子</p><p style="font-size:16px;font-family:微软雅黑;"><span><br/></span><br/></p>',
								DownloadCode: null,
								XmlCode: null,
								XMLFragmentationCode: null,
								ModuleCode: 'b5b6dfac-feed-43f9-b386-ea5d1890f070',
								ModuleName: null,
								ExtType: null,
								CourseCode: 'a27e86db-4661-4d5e-8fc4-48b25bdd638b',
								UserId: '0f79635f-80c0-4a6e-a634-30b925a9413a',
								RealName: '熊凡',
								UserName: null,
								SubmitUserName: '熊凡',
								DiscussStatus: 0,
								DiscussId: null,
								LiveDiscussLink: null,
								LiveDiscussStatus: 0,
								LiveDiscussId: null,
								DiscussLink: null,
								ReviewFlag: 0,
								ReviewFlagHanZi: null,
								ReviewMark: null,
								PostTime: '2019-08-26T14:27:25Z',
								DownloadLink: null,
								FileType: 0,
								CatalogHtml: null,
								Extension: null,
								ReviewFlagShu: 0,
								ZiYuanZongShu: 0,
								ResourceTypeShu: 0,
								LiteratureID: null,
								IsPublic: 0,
								MiniDiscussList: null,
								Exercise: null,
								CataLogName: null,
								Stage: null,
								SubjectName: null,
								CourseVersion: null,
								CourseName: null,
								IsMy: 0,
								IsCNKI: 0,
								AddSource: 0,
								Link: null,
								FileSize: null,
								IsTencent: 0,
								ShowNo: 6,
								InitialResourceName: 'maven简介_课程内容',
								HasArranged: false,
								IsRead: 1,
								IsDownLoad: 0,
								Synthesis: 0
							},
							{
								ResourceCode: '44761e0d-e9bf-4a99-949c-721b68d0f129',
								ResourceName: 'xxxx',
								ResourceType: 'richtext',
								Content:
									'<h2 style="font-size:24px;font-family:微软雅黑;"><span style="font-family: 宋体;font-size: 14.7px"><span style="font-family:宋体">课题</span>2 <span style="font-family:宋体">化学是一门以实验为基础的科学</span></span></h2><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style="font-family: 宋体;line-height: 114%;font-size: 14.7px"><span style="font-family:宋体">探究一：对蜡烛及其燃烧的探究</span></span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style="font-family: 宋体;line-height: 114%;font-size: 14.7px"><span style="font-family:宋体"></span></span></p><p style="font-size:16px;font-family:微软雅黑;text-align:center"><img data_source="ee671208-c95c-42e1-8451-1acbd2bdbcdf" src="http://ve.cnki.net/coeduApi/api/File/ShowFile?filecode=b74994ab-0b8f-44e6-9511-4c070d7eff5f.png" data-meta="Qz4Mz30lerVn_c3C_QykxeU_a1A_M5o6hXPDJArbK_a1A_CdxrFouVnmMFA4NWAwzBaFa0WVCiamB0OCd66dcc0yi_a1A_s8h9l1eIFfFwcqpN8vxX2PyQWafqWon2vnubIHG6jbteZAHm8cQ6Yy1_a1A_tsy_c3C_DCfPurwuM6XcyuxrteFxGG545kCVIGn6hLuG4j32SMOXOloSUnUVMd4p1h5fduJGRS_a1A_4_a1A_MEO8096_a1A_nlycIGRUofya1DOj43tDjl4IS1JU8CAOK_c3C_ewG4vaLZprgNW_a1A_b5re4zncB2M7T6bJFrZFfTYJKxyb0dzvj6pt57mq_a1A_Uhf5N8tyJ53j3FGZjWaDYb8pHsZ2FYhCOL1OLRTOG1n2C2itmdV9ISqZ37o_b2B_" style="max-width:100%;cursor:pointer;" role="999" class="video_fake_img" data-nopop="1" onclick="parent.weditor.open(this)" width="360" height="200"/></p><p style="font-size:16px;font-family:微软雅黑;text-align:center">003z8pwVlx07lnOblRP201040200629w0k010</p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style="font-family: 宋体;line-height: 114%;font-size: 14.7px"><span style="font-family:宋体"><br/></span></span><br/></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style=";font-family:宋体;line-height:114%;font-size:14.0px"><span style="font-family:宋体">展示蜡烛</span>:学生观察--</span><span style=";font-family:Wingdings;line-height:114%;font-size:14.0px">à</span><span style=";font-family:宋体;line-height:114%;font-size:14.0px"><span style="font-family:宋体">点燃蜡烛，分小组完整的观察蜡烛燃烧的现象</span>---</span><span style=";font-family:Wingdings;line-height:114%;font-size:14.0px">à</span><span style=";font-family:宋体;line-height:114%;font-size:14.0px"><span style="font-family:宋体">蜡烛熄灭后又有什么现象？</span></span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style=";font-family:宋体;line-height:114%;font-size:14.0px"><span style="font-family:宋体">完成实验报告</span></span></p><table width="642" border="1" rules="all" style="width: 626px;"><tbody><tr class="firstRow"><td width="642" valign="bottom" colspan="3" style="" align="left"><span style="font-family: 宋体;font-size: 14.0px">实验报告</span></td></tr><tr><td width="642" valign="bottom" colspan="3" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">姓名</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;</span></span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;</span></span><span style="font-family:宋体;font-size:14.0px">&nbsp;</span><span style=";font-family:宋体;font-size:14.0px">合作者</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;</span></span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=";font-family:宋体;font-size:14.0px">班级</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;</span></span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;</span></span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;</span></span><span style=";font-family:宋体;font-size:14.0px">日期</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;</span></span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span></td></tr><tr><td width="235" valign="bottom" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">步骤和方法</span></td><td width="198" valign="bottom" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">现象</span></td><td width="207" valign="bottom" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">结论</span></td></tr><tr style="height:35.5px"><td width="235" valign="center" rowspan="2" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">1.点燃前：观察蜡烛，并切下一小片石蜡放在水里。</span></td><td width="198" valign="center" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">石蜡是一种</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style="font-family:宋体;font-size:14.0px">色</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=";font-family:宋体;font-size:14.0px">体，</span></td><td width="207" valign="bottom" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">硬度</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;</span></span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;</span></span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;</span></span></td></tr><tr style="height:35.5px"><td width="198" valign="center" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">&nbsp;&nbsp;&nbsp;溶于水，浮在水面上</span></td><td width="207" valign="bottom" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">说明石蜡密度比水</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;</span></span></td></tr><tr style="height:35.7px"><td width="235" valign="center" rowspan="4" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">2.点燃蜡烛：并观察，然后取一根火柴梗平放入火焰中。</span></td><td width="198" valign="center" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">蜡烛 </span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=";font-family:宋体;font-size:14.0px">&nbsp;&nbsp;&nbsp;&nbsp;</span></td><td width="207" valign="bottom" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">说明石蜡具有</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style="font-family:宋体;font-size:14.0px">性</span></td></tr><tr style="height:35.7px"><td width="198" valign="center" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">靠近火焰的石蜡熔化成</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=";font-family:宋体;font-size:14.0px">&nbsp;&nbsp;&nbsp;</span></td><td width="207" valign="bottom" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">说明石蜡熔点较</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span></td></tr><tr style="height:35.7px"><td width="198" valign="center" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">火焰分</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=";font-family:宋体;font-size:14.0px">层，火柴棒最先碳化变黑的部分是 </span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span></td><td width="207" valign="bottom" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">说明</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=";font-family:宋体;font-size:14.0px">温度最高</span></td></tr><tr style="height:35.7px"><td width="198" valign="center" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">蜡烛燃烧不充分时会产生</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style="font-family:宋体;font-size:14.0px">&nbsp;</span></td><td width="207" valign="bottom" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">黑烟的成分是</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span></td></tr><tr><td width="235" valign="center" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">3.把一个干冷小烧杯罩在火焰上方。</span></td><td width="198" valign="center" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">烧杯内壁有</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=";font-family:宋体;font-size:14.0px">出现</span></td><td width="207" valign="bottom" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">说明蜡烛燃烧有</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=";font-family:宋体;font-size:14.0px">生成</span></td></tr><tr><td width="235" valign="center" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">4.把一个内壁涂有澄清石灰水的小烧杯罩在火焰上方。</span></td><td width="198" valign="center" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">澄清石灰水变</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span></td><td width="207" valign="bottom" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">说明蜡烛燃烧有</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=";font-family:宋体;font-size:14.0px">生成</span></td></tr><tr><td width="235" valign="center" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">5.蜡烛熄灭观察现象</span></td><td width="198" valign="center" style="" align="left"><span style="font-family:宋体;font-size:14.0px">有</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=";font-family:宋体;font-size:14.0px">产生</span></td><td width="207" valign="bottom" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">白烟是</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=";font-family:宋体;font-size:14.0px">蒸气遇冷凝结成得石蜡小颗粒。</span></td></tr><tr><td width="235" valign="bottom" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">6.点燃白烟</span></td><td width="198" valign="bottom" style="" align="left"><br/></td><td width="207" valign="bottom" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">说明石蜡具有</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style="font-family:宋体;font-size:14.0px">性</span></td></tr><tr><td width="642" valign="bottom" colspan="3" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">写出蜡烛燃烧的文字表达式： &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></td></tr></tbody></table><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style="font-family: 宋体;line-height: 114%;font-size: 14.0px"><span style="font-family:宋体">探究二：对人体吸入的空气和呼出的气体的探究</span></span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style=";font-family:宋体;line-height:114%;font-size:14.0px"><span style="font-family:宋体">实验用品：集气瓶（</span>4个） 水槽 &nbsp;玻璃片（4个）饮料管 澄清石灰水 &nbsp;滴管 &nbsp;火柴（或木条）</span></p><table width="625" border="1" rules="all"><tbody><tr class="firstRow"><td width="127" valign="top" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">探究内容</span></td><td width="164" valign="top" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">实验步骤</span></td><td width="215" valign="top" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">实验现象</span></td><td width="119" valign="top" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">结论</span></td></tr><tr><td width="127" valign="top" style="" align="left"><span style="font-family:宋体;font-size:14.0px">&nbsp;</span><span style=";font-family:宋体;font-size:14.0px">排水法收集2瓶呼出的气体</span></td><td width="164" valign="top" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">在两个集气瓶中装满水，用玻璃片盖住瓶口，倒立放入水中，将塑料吸管小心插入集气瓶内，吹气</span></td><td width="215" valign="top" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">集气瓶中的水被排出，集气瓶内充满你呼出的气体</span></td><td width="119" valign="top" style="" align="left"><span style="font-family:Calibri;font-size:14.0px"><span style="position:absolute;z-index:1;margin-top:3.7333px;width:119.0000px;height:90.0000px"></span></span><span style="font-family:宋体;font-size:14.0px">&nbsp;</span></td></tr><tr><td width="127" valign="top" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">探究二氧化碳含量是否相同</span></td><td width="164" valign="top" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">向盛有空气的集气瓶和呼出气体的集气瓶中分别加入少量石灰水，震荡</span></td><td width="215" valign="top" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">呼出的气体中石灰水</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style="font-family:宋体;font-size:14.0px">；</span><span style="text-decoration:underline;"></span><span style=";font-family:宋体;font-size:14.0px">空气中石灰水</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style="font-family:宋体;font-size:14.0px">。</span><span style="text-decoration:underline;"></span></td><td width="119" valign="top" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">人呼出的气体比空气中二氧化碳含量</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span></td></tr><tr><td width="127" valign="top" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">探究氧气含量是否相同</span></td><td width="164" valign="top" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">将燃着的木条分别伸入盛有空气和呼出气体的集气瓶中。</span></td><td width="215" valign="top" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">木条在呼出的气体中</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=";font-family:宋体;font-size:14.0px">&nbsp;；</span><span style=";font-family:宋体;font-size:14.0px">木条在空气中</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style="font-family:宋体;font-size:14.0px">。</span></td><td width="119" valign="top" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">人呼出的气体比空气中氧气的含量</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span></td></tr><tr><td width="127" valign="top" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">探究水蒸气含量是否相同</span></td><td width="164" valign="top" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">取两个玻璃片，对其中一个呼气，另一片放在空气中</span></td><td width="215" valign="top" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">呼气的玻璃片上</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style="font-family:宋体;font-size:14.0px">；</span><span style="text-decoration:underline;"></span><span style=";font-family:宋体;font-size:14.0px">空气中的玻璃片</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style="font-family:宋体;font-size:14.0px">。</span><span style="text-decoration:underline;"></span></td><td width="119" valign="top" style="" align="left"><span style=";font-family:宋体;font-size:14.0px">人呼出的气体比空气中水蒸气含量 </span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span></td></tr></tbody></table><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style="font-family: 宋体;font-size: 14.0px"><span style="font-family:宋体">【课堂小结】</span></span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style="font-family:宋体;font-size:14.0px">1.&nbsp;</span><span style=";font-family:宋体;font-size:14.0px"><span style="font-family:宋体">观察实验分为</span> </span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=";font-family:宋体;font-size:14.0px"><span style="font-family:宋体">、</span></span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=";font-family:宋体;font-size:14.0px"><span style="font-family:宋体">、</span></span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=";font-family:宋体;font-size:14.0px"><span style="font-family:宋体">三个阶段。</span></span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style="font-family:宋体;font-size:14.0px">2.&nbsp;</span><span style=";font-family:宋体;font-size:14.0px"><span style="font-family:宋体">科学探究的一般流程包括：</span></span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style=";font-family:宋体;font-size:14.0px"><span style="font-family:宋体">提出</span></span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=";font-family:宋体;font-size:14.0px"><span style="font-family:宋体">、</span></span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=";font-family:宋体;font-size:14.0px"><span style="font-family:宋体">、设计</span></span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=";font-family:宋体;font-size:14.0px"><span style="font-family:宋体">、进行</span></span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=";font-family:宋体;font-size:14.0px"><span style="font-family:宋体">、得出</span></span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=";font-family:宋体;font-size:14.0px"><span style="font-family:宋体">、反思与评价。</span></span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style=";font-family:宋体;font-size:14.0px">3.蜡烛燃烧生成水的检验方法：</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=";font-family:宋体;font-size:14.0px">&nbsp;<span style="font-family:宋体">。</span></span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style=";font-family:宋体;font-size:14.0px">4.蜡烛燃烧生成二氧化碳的检验方法：</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=";font-family:宋体;font-size:14.0px"><span style="font-family:宋体">。</span></span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style="font-family: 宋体;font-size: 14.0px"><span style="font-family:宋体">【</span></span><span style="font-family: 宋体;line-height: 114%;font-size: 14.0px"><span style="font-family:宋体">巩固提升</span></span><span style="font-family: 宋体;font-size: 14.0px"><span style="font-family:宋体">】</span></span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style=";font-family:宋体;font-size:14.0px">1.能使澄清石灰水变浑浊的气体是 </span><span style=";font-family:宋体;font-size:14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style=";font-family:宋体;font-size:14.0px"><span style="font-family:宋体">（</span> &nbsp;&nbsp;<span style="font-family:宋体">）</span></span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style=";font-family:宋体;font-size:14.0px">A.空气 &nbsp;&nbsp;&nbsp;</span><span style=";font-family:宋体;font-size:14.0px">&nbsp;&nbsp;</span><span style=";font-family:宋体;font-size:14.0px">&nbsp;B.水蒸气 &nbsp;</span><span style=";font-family:宋体;font-size:14.0px">&nbsp;&nbsp;&nbsp;&nbsp;</span><span style=";font-family:宋体;font-size:14.0px">&nbsp;&nbsp;C.氧气 &nbsp;&nbsp;</span><span style=";font-family:宋体;font-size:14.0px">&nbsp;&nbsp;</span><span style=";font-family:宋体;font-size:14.0px">&nbsp;&nbsp;D.二氧化碳</span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style=";font-family:宋体;font-size:14.0px">2.有关蜡烛性质和实验现象的叙述错误的是 </span><span style=";font-family:宋体;font-size:14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style=";font-family:宋体;font-size:14.0px"><span style="font-family:宋体">（</span> &nbsp;&nbsp;<span style="font-family:宋体">）</span></span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style=";font-family:宋体;font-size:14.0px">A.蜡烛燃烧后生成的气体可以使澄清的石灰水变浑浊。</span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style=";font-family:宋体;font-size:14.0px">B.蜡烛燃烧的同时伴有熔化过程。</span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style=";font-family:宋体;font-size:14.0px">C.用火柴点燃蜡烛刚熄灭时的白烟，蜡烛能重新燃烧。</span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style=";font-family:宋体;font-size:14.0px">D.蜡烛在空气中燃烧发出白色火焰，放热并产生白烟。</span></p><p style="font-size:16px;font-family:微软雅黑;"><span style="font-family: 宋体;font-size: 14.0px">3. 小军同学在做家庭小实验时．向热的大米粥中加入碘酒，发现未变蓝色。面对“异常”现象，</span></p><p style="font-size:16px;font-family:微软雅黑;text-indent:14.0px;"><span style="font-family: 宋体;font-size: 14.0px"><span style="font-family:宋体">他不应该采取的做法是</span> </span><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="font-family: 宋体;font-size: 14.0px"><span style="font-family:宋体">（</span> &nbsp;&nbsp;<span style="font-family:宋体">）</span> </span></p><p style="font-size:16px;font-family:微软雅黑;text-indent:14.0px;"><span style="font-family: 宋体;font-size: 14.0px">A．向老师请教 </span><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="font-family: 宋体;font-size: 14.0px">B．查找相关资料，探究原因</span></p><p style="font-size:16px;font-family:微软雅黑;text-indent:14.0px;"><span style="font-family: 宋体;font-size: 14.0px">C．反复实验并观察是否有相同现象 </span><span style="font-family: 宋体;font-size: 14.0px">&nbsp;</span><span style="font-family: 宋体;font-size: 14.0px">D．认为自己做错了</span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style=";font-family:宋体;font-size:14.0px">4</span><span style=";font-family:宋体;font-size:14.0px">.某同学在化学课上提出：可用澄清石灰水来检验人呼出的气体中是否含有二氧化碳。就这一</span></p><p style="font-size:16px;font-family:微软雅黑;text-indent:14.0px;line-height:114%;"><span style=";font-family:宋体;font-size:14.0px"><span style="font-family:宋体">过程而言，属于科学探究环节中的</span> </span><span style=";font-family:宋体;font-size:14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style=";font-family:宋体;font-size:14.0px"><span style="font-family:宋体">（</span> &nbsp;&nbsp;<span style="font-family:宋体">）</span></span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style=";font-family:宋体;font-size:14.0px">A．建立假设 &nbsp;&nbsp;&nbsp;B．收集证据 &nbsp;&nbsp;&nbsp;&nbsp;C．设计实验 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;D．做出结论</span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style=";font-family:宋体;font-size:14.0px">5.点燃蜡烛，可以观察到蜡烛的火焰分＿＿＿＿层。取一根火柴梗，拿住一端迅速平放入火焰中，观察</span></p><p style="font-size:16px;font-family:微软雅黑;text-indent:14.0px;line-height:114%;"><span style=";font-family:宋体;font-size:14.0px"><span style="font-family:宋体">并比较火柴梗在火焰的不同部位被烧的情况：＿＿＿＿部分被烧得最焦，说明火焰＿＿＿＿温度最高。</span></span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style="position:absolute;z-index:1;margin-left:492.4000px;margin-top:38.0000px;width:108.0000px;height:105.0000px"><img width="108" height="105" src="http://ve.cnki.net/Editor/ueditor/themes/default/images/spacer.gif" style="background:url(http://ve.cnki.net/Editor/ueditor/themes/default/images/word.gif) no-repeat center center;border:1px solid #ddd"/></span><span style=";font-family:宋体;font-size:14.0px">6.点燃一支蜡烛，把一个冷碟子放在蜡烛火焰的上方（如下图所示），过一会儿后，在冷碟子的底部会收集到新制的炭黑。这个实验说明了 </span><span style=";font-family:宋体;font-size:14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style=";font-family:宋体;font-size:14.0px"><span style="font-family:宋体">（</span> &nbsp;&nbsp;&nbsp;&nbsp;<span style="font-family:宋体">）</span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style=";font-family:宋体;font-size:14.0px">A．由于氧气不足蜡烛不完全燃烧而生成了炭黑</span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style=";font-family:宋体;font-size:14.0px">B．挥发的蜡烛遇冷后凝结而成炭黑</span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style=";font-family:宋体;font-size:14.0px">C．蜡烛的燃烧可以不需要氧气参与</span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style=";font-family:宋体;font-size:14.0px">D．蜡烛中本身不含有碳元素，但燃烧后生成了碳单质</span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style="font-family: 宋体;font-size: 14.0px"><br/></span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style="font-family: 宋体;font-size: 14.0px">7.1元硬币的外观有银白色的金属光泽，一些同学认为它可能是由铁制成的。在讨论时有同学提出“拿磁铁吸一下”。就“拿磁铁吸一下”这一过程而言，属于科学探究中的 </span><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="font-family: 宋体;font-size: 14.0px"><span style="font-family:宋体">（</span> &nbsp;&nbsp;</span><span style="font-family: 宋体;font-size: 14.0px">&nbsp;</span><span style="font-family: 宋体;font-size: 14.0px">&nbsp;<span style="font-family:宋体">）</span></span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;A ．实验 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;B ．假设 &nbsp;&nbsp;&nbsp;&nbsp;C ．观察 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;D ．作结论 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style="font-family: 宋体;font-size: 14.0px">8.下列气体中，能够使澄清石灰水变浑浊的是</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style="font-family: 宋体;font-size: 14.0px"><span style="font-family:宋体">，能使带火星的木条复燃的是</span></span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;</span></span><span style="font-family: 宋体;font-size: 14.0px"><span style="font-family:宋体">，人体通过呼吸作用生成的气体有</span></span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style="font-family: 宋体;font-size: 14.0px"><span style="font-family:宋体">，绿色植物光合作用产生的气体是</span></span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style="font-family: 宋体;font-size: 14.0px"><span style="font-family:宋体">，从冰箱取出瓶装的饮料放在空气中，不久瓶的外壁出现水珠，这说明空气中含有</span></span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style="font-family: 宋体;font-size: 14.0px"><span style="font-family:宋体">。</span> </span></p><p style="font-size:16px;font-family:微软雅黑;text-indent:21.0px;line-height:114%;"><span style="font-family: 宋体;font-size: 14.0px">A．氧气 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;B．二氧化碳 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;C．水蒸气 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;D．空气</span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style="font-family: 宋体;font-size: 14.0px">9.</span><span style="font-family: 宋体;line-height: 114%;font-size: 14.0px"><span style="font-family:宋体">在</span>“人吸收的空气和呼出的气体有什么不同”的探究中，下列说法不正确的是 </span><span style="font-family: 宋体;line-height: 114%;font-size: 14.0px">&nbsp;</span><span style="font-family: 宋体;line-height: 114%;font-size: 14.0px"><span style="font-family:宋体">（</span> &nbsp;&nbsp;</span><span style="font-family: 宋体;line-height: 114%;font-size: 14.0px">&nbsp;</span><span style="font-family: 宋体;line-height: 114%;font-size: 14.0px">&nbsp;<span style="font-family:宋体">）</span></span></p><p style="font-size:16px;font-family:微软雅黑;text-indent:21.0px;line-height:114%;"><span style="font-family: 宋体;line-height: 114%;font-size: 14.0px">A．证明呼出气体含二氧化碳多的证据是：呼出的气体使澄清石灰水变浑浊</span></p><p style="font-size:16px;font-family:微软雅黑;text-indent:21.0px;line-height:114%;"><span style="font-family: 宋体;line-height: 114%;font-size: 14.0px">B．证明呼出的气体含氧气少的证据是：呼出的气体使木条燃烧更旺</span></p><p style="font-size:16px;font-family:微软雅黑;text-indent:21.0px;line-height:114%;"><span style="font-family: 宋体;line-height: 114%;font-size: 14.0px">C．证明呼出气体含水蒸气多的证据是：呼出的气体在玻璃片上结成水珠</span></p><p style="font-size:16px;font-family:微软雅黑;text-indent:21.0px;line-height:114%;"><span style="font-family: 宋体;line-height: 114%;font-size: 14.0px">D．判断呼出气体含有氮气的依据是：空气中含有氮气，而氮气不为人体吸入。</span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style="font-family: 宋体;line-height: 114%;font-size: 14.0px">10.</span><span style="font-family: 宋体;font-size: 14.0px"><span style="font-family:宋体">进行科学探究是学好化学的一个重要手段。下列选项与科学探究有关的是</span> &nbsp;</span><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;</span><span style="font-family: 宋体;font-size: 14.0px">&nbsp;</span><span style="font-family: 宋体;font-size: 14.0px">&nbsp;</span><span style="font-family: 宋体;font-size: 14.0px"><span style="font-family:宋体">（</span> &nbsp;</span><span style="font-family: 宋体;font-size: 14.0px">&nbsp;</span><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;<span style="font-family:宋体">）</span> </span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style="font-family: 宋体;font-size: 14.0px">① 提出合理假设或猜想 ② 设计探究实验步骤 ③ 记录实验现象和相关数据 ④ 合作进行化学实验 ⑤ 完成实验报告 </span></p><p style="font-size:16px;font-family:微软雅黑;text-indent:21.0px;line-height:114%;"><span style="font-family: 宋体;font-size: 14.0px">A．①③⑤ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;B．①②③ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;C． ①②③⑤ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;D． ①②③④⑤</span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style="font-family: 宋体;font-size: 14.0px">11.如右图所示，某同学为验证空气中含有少量二氧化碳，将大针筒内的空气一次性压入新制的澄清石灰水，发现石灰水没有变化。据此，你认为该同学应该 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="font-family: 宋体;font-size: 14.0px"><span style="font-family:宋体">（</span> &nbsp;</span><span style="font-family: 宋体;font-size: 14.0px">&nbsp;</span><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;<span style="font-family:宋体">）</span></span></p><p style="font-size:16px;font-family:微软雅黑;text-indent:21.0px;line-height:114%;"><span style="position:absolute;z-index:1;margin-left:348.0000px;margin-top:9.6667px;width:120.0000px;height:64.0000px"><img width="120" height="64" src="http://ve.cnki.net/Editor/ueditor/themes/default/images/spacer.gif" style="background:url(http://ve.cnki.net/Editor/ueditor/themes/default/images/word.gif) no-repeat center center;border:1px solid #ddd"/></span><span style="font-family: 宋体;font-size: 14.0px">A．继续用大针筒向澄清石灰水压入空气 </span></p><p style="font-size:16px;font-family:微软雅黑;text-indent:21.0px;line-height:114%;"><span style="font-family: 宋体;font-size: 14.0px">B．撤去大针筒，用嘴向澄清石灰水吹气 </span></p><p style="font-size:16px;font-family:微软雅黑;text-indent:21.0px;line-height:114%;"><span style="font-family: 宋体;font-size: 14.0px">C．得出空气中没有二氧化碳的结论 </span></p><p style="font-size:16px;font-family:微软雅黑;text-indent:21.0px;line-height:114%;"><span style="font-family: 宋体;font-size: 14.0px">D．得出空气中含有少量二氧化碳的结论</span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style=";font-family:宋体;font-size:14.0px">12.</span><span style=";font-family:宋体;font-size:14.0px"><span style="font-family:宋体">蜡烛刚熄灭时，总会有一缕白烟冒出。</span></span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style=";font-family:宋体;font-size:14.0px"><span style="font-family:宋体">【提出问题】蜡烛刚熄灭时产生的白烟是什么？</span></span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style=";font-family:宋体;font-size:14.0px"><span style="font-family:宋体">【猜想假设】</span>①白烟是燃烧时产生的二氧化碳；②白烟是燃烧时生成的水蒸气；</span></p><p style="font-size:16px;font-family:微软雅黑;text-indent:84.0px;line-height:114%;"><span style=";font-family:宋体;font-size:14.0px">③白烟是石蜡整齐凝成的石蜡固体小颗粒。</span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style=";font-family:宋体;font-size:14.0px"><span style="font-family:宋体">【设计实验】</span></span></p><p style="font-size:16px;font-family:微软雅黑;"><span style=";font-family:宋体;font-size:14.0px"><span style="font-family:宋体">（</span>1）吹灭蜡烛，立即用一个蘸有澄清石灰水的烧杯罩住白烟，其目的是为了验证假设＿＿（填序号），但是这样做并不能得出正确的结论，原因是</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style="text-decoration:underline;"></span></p><p style="font-size:16px;font-family:微软雅黑;"><span style=";font-family:宋体;font-size:14.0px"><span style="font-family:宋体">（</span>2）吹灭蜡烛，立即用一个干而冷的玻璃片放在白烟上，玻璃片上没有水雾出现，说明白烟不是 &nbsp;&nbsp;&nbsp;＿，假设＿＿＿＿＿不成立。</span></p><p style="font-size:16px;font-family:微软雅黑;"><span style=";font-family:宋体;font-size:14.0px"><span style="font-family:宋体">（</span>3）吹灭蜡烛，立即用燃着的木条去点白烟，发现蜡烛重新被点燃，说明白烟具有可燃性，</span></p><p style="font-size:16px;font-family:微软雅黑;text-indent:14.0px;"><span style=";font-family:宋体;font-size:14.0px"><span style="font-family:宋体">这是为假设＿＿＿＿＿提供了证据。同时可排除假设＿＿＿＿，因为＿＿＿＿＿＿＿＿＿。</span></span></p><p style="font-size:16px;font-family:微软雅黑;"><span style=";font-family:宋体;font-size:14.0px"><span style="font-family:宋体">【得出结论】蜡烛刚熄灭时产生的白烟是</span></span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=";font-family:宋体;font-size:14.0px"><span style="font-family:宋体">。</span></span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style="position:absolute;z-index:1;margin-left:534.0000px;width:51.0000px;height:68.0000px"><img width="51" height="68" src="http://ve.cnki.net/Editor/ueditor/themes/default/images/spacer.gif" style="background:url(http://ve.cnki.net/Editor/ueditor/themes/default/images/word.gif) no-repeat center center;border:1px solid #ddd"/></span><span style="font-family: 宋体;font-size: 14.0px">13.某同学对蜡烛（主要成分是石蜡）及其燃烧进行了如下探究。请填写下列空格：</span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style="font-family: 宋体;font-size: 14.0px"><span style="font-family:宋体">（</span>1）取一支蜡烛，用小刀切下一小块，把它放入水中，蜡烛浮在水面上。</span></p><p style="font-size:16px;font-family:微软雅黑;text-indent:35.0px;line-height:114%;"><span style="font-family: 宋体;font-size: 14.0px"><span style="font-family:宋体">结论：石蜡的密度比水</span></span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style="font-family: 宋体;font-size: 14.0px"><span style="font-family:宋体">。</span></span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style="font-family: 宋体;font-size: 14.0px"><span style="font-family:宋体">（</span>2）点燃蜡烛，观察到蜡烛火焰分为</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style="font-family: 宋体;font-size: 14.0px"><span style="font-family:宋体">、</span></span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style="font-family: 宋体;font-size: 14.0px"><span style="font-family:宋体">、</span></span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style="font-family: 宋体;font-size: 14.0px"><span style="font-family:宋体">三层。把一根火柴梗横放在蜡烛的火焰中（如右图）约</span> 15 后取出，可以看到火柴梗的</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style="font-family: 宋体;font-size: 14.0px"><span style="font-family:宋体">（填</span>“a”、“b”或“c”）处最先炭化。结论：蜡烛火焰的</span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style="font-family: 宋体;font-size: 14.0px"><span style="font-family:宋体">层温度最高。</span></span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style="font-family: 宋体;font-size: 14.0px"><span style="font-family:宋体">（</span>3）再将一只干燥的烧杯罩在蜡烛火焰上方，烧杯内壁出现水雾。取下烧杯，迅速向烧杯内倒入少量澄清的石灰水，振荡，澄清石灰水变浑浊。</span></p><p style="font-size:16px;font-family:微软雅黑;line-height:114%;"><span style="font-family: 宋体;font-size: 14.0px"><span style="font-family:宋体">结论：石蜡燃烧后一定有</span></span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style="font-family: 宋体;font-size: 14.0px"><span style="font-family:宋体">、</span></span><span style="text-decoration:underline;"><span style="font-family: 宋体;font-size: 14.0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style="font-family: 宋体;font-size: 14.0px"><span style="font-family:宋体">生成。</span></span></p><p style="font-size:16px;font-family:微软雅黑;"><span style=";font-family:Calibri;font-size:14.0px">&nbsp;</span></p><p style="font-size:16px;font-family:微软雅黑;"><br/></p>',
								DownloadCode: null,
								XmlCode: null,
								XMLFragmentationCode: null,
								ModuleCode: 'b5b6dfac-feed-43f9-b386-ea5d1890f070',
								ModuleName: null,
								ExtType: null,
								CourseCode: 'a27e86db-4661-4d5e-8fc4-48b25bdd638b',
								UserId: '0f79635f-80c0-4a6e-a634-30b925a9413a',
								RealName: '熊凡',
								UserName: null,
								SubmitUserName: '熊凡',
								DiscussStatus: 0,
								DiscussId: null,
								LiveDiscussLink: null,
								LiveDiscussStatus: 0,
								LiveDiscussId: null,
								DiscussLink: null,
								ReviewFlag: 0,
								ReviewFlagHanZi: null,
								ReviewMark: null,
								PostTime: '2019-09-23T09:31:05Z',
								DownloadLink: null,
								FileType: 0,
								CatalogHtml: null,
								Extension: null,
								ReviewFlagShu: 0,
								ZiYuanZongShu: 0,
								ResourceTypeShu: 0,
								LiteratureID: null,
								IsPublic: 0,
								MiniDiscussList: null,
								Exercise: null,
								CataLogName: null,
								Stage: null,
								SubjectName: null,
								CourseVersion: null,
								CourseName: null,
								IsMy: 0,
								IsCNKI: 0,
								AddSource: 0,
								Link: null,
								FileSize: null,
								IsTencent: 0,
								ShowNo: 7,
								InitialResourceName: 'xxxx',
								HasArranged: false,
								IsRead: 1,
								IsDownLoad: 0,
								Synthesis: 0
							}
						],
						CoHomeWorks: null,
						Content: null,
						ResourceCode: null,
						ContentFlag: 0,
						HomeworkSubmitFlag: 0,
						Introduction: null,
						StudentWork: null,
						CanDelete: 0,
						ResourceCount: 0,
						PModuleCode: null
					},
					{
						ModuleCode: 'e0c8348a-b4ca-46cd-b8a8-fcb4e385d077',
						ModuleName: '课件PPT',
						CourseCode: 'a27e86db-4661-4d5e-8fc4-48b25bdd638b',
						ModuleType: '资源列表',
						UserId: '0f79635f-80c0-4a6e-a634-30b925a9413a',
						ShowNo: 3,
						OwnerCode: 'f32950c9-9576-469f-b2c4-b001a2f68be0',
						DownloadFlag: 0,
						DiscussStatus: 0,
						ReviewFlag: 0,
						StudentFlag: 0,
						ReviewStatus: 0,
						ReviewMark: null,
						WenBenFlag: 0,
						KongFlag: 0,
						LianJieFlag: 0,
						TuPianFlag: 0,
						KeJianFlag: 0,
						ShiPinFlag: 0,
						UserName: null,
						PostTime: '2019-05-10T16:02:02Z',
						ExtOne: 0,
						ExtTwo: 0,
						CoResourceView: [
							{
								ResourceCode: '5c8bb89d-ea51-4166-a1ee-088d76b405da',
								ResourceName: '123.pdf',
								ResourceType: 'pdf',
								Content: null,
								DownloadCode: '348c3323-1cd3-44ec-b609-bb6eab8d0973.pdf',
								XmlCode: '348c3323-1cd3-44ec-b609-bb6eab8d0973.pdf|',
								XMLFragmentationCode: null,
								ModuleCode: 'e0c8348a-b4ca-46cd-b8a8-fcb4e385d077',
								ModuleName: null,
								ExtType: null,
								CourseCode: 'a27e86db-4661-4d5e-8fc4-48b25bdd638b',
								UserId: '0f79635f-80c0-4a6e-a634-30b925a9413a',
								RealName: '熊凡',
								UserName: null,
								SubmitUserName: '熊凡',
								DiscussStatus: 0,
								DiscussId: null,
								LiveDiscussLink: null,
								LiveDiscussStatus: 0,
								LiveDiscussId: null,
								DiscussLink: null,
								ReviewFlag: 0,
								ReviewFlagHanZi: null,
								ReviewMark: null,
								PostTime: '2019-06-18T09:42:25Z',
								DownloadLink: null,
								FileType: 0,
								CatalogHtml: null,
								Extension: null,
								ReviewFlagShu: 0,
								ZiYuanZongShu: 0,
								ResourceTypeShu: 0,
								LiteratureID: null,
								IsPublic: 0,
								MiniDiscussList: null,
								Exercise: null,
								CataLogName: null,
								Stage: null,
								SubjectName: null,
								CourseVersion: null,
								CourseName: null,
								IsMy: 0,
								IsCNKI: 0,
								AddSource: 0,
								Link: null,
								FileSize: '1635523',
								IsTencent: 0,
								ShowNo: 1,
								InitialResourceName: '123.pdf',
								HasArranged: false,
								IsRead: 1,
								IsDownLoad: 1,
								Synthesis: 0
							},
							{
								ResourceCode: 'fc5bf5f9-8e82-4119-abd6-5636019fca14',
								ResourceName: '酸的化学性质（课件）.ppt',
								ResourceType: 'presentation',
								Content: null,
								DownloadCode: '0e5f2d6e-1536-4029-91a3-0ff7d23655cb.ppt',
								XmlCode: '0e5f2d6e-1536-4029-91a3-0ff7d23655cb.ppt|',
								XMLFragmentationCode: null,
								ModuleCode: 'e0c8348a-b4ca-46cd-b8a8-fcb4e385d077',
								ModuleName: null,
								ExtType: null,
								CourseCode: 'a27e86db-4661-4d5e-8fc4-48b25bdd638b',
								UserId: '0f79635f-80c0-4a6e-a634-30b925a9413a',
								RealName: '熊凡',
								UserName: null,
								SubmitUserName: '熊凡',
								DiscussStatus: 0,
								DiscussId: null,
								LiveDiscussLink: null,
								LiveDiscussStatus: 0,
								LiveDiscussId: null,
								DiscussLink: null,
								ReviewFlag: 0,
								ReviewFlagHanZi: null,
								ReviewMark: null,
								PostTime: '2019-08-08T17:44:08Z',
								DownloadLink: null,
								FileType: 0,
								CatalogHtml: null,
								Extension: null,
								ReviewFlagShu: 0,
								ZiYuanZongShu: 0,
								ResourceTypeShu: 0,
								LiteratureID: null,
								IsPublic: 0,
								MiniDiscussList: null,
								Exercise: null,
								CataLogName: null,
								Stage: null,
								SubjectName: null,
								CourseVersion: null,
								CourseName: null,
								IsMy: 0,
								IsCNKI: 0,
								AddSource: 0,
								Link: null,
								FileSize: '3734016',
								IsTencent: 0,
								ShowNo: 2,
								InitialResourceName: '酸的化学性质（课件）.ppt',
								HasArranged: false,
								IsRead: 1,
								IsDownLoad: 0,
								Synthesis: 0
							}
						],
						CoHomeWorks: null,
						Content: null,
						ResourceCode: null,
						ContentFlag: 0,
						HomeworkSubmitFlag: 0,
						Introduction: null,
						StudentWork: null,
						CanDelete: 0,
						ResourceCount: 0,
						PModuleCode: null
					},
					{
						ModuleCode: 'a124c46d-ec1e-41be-a841-616d7290b8de',
						ModuleName: '拓展资源',
						CourseCode: 'a27e86db-4661-4d5e-8fc4-48b25bdd638b',
						ModuleType: '资源列表',
						UserId: '0f79635f-80c0-4a6e-a634-30b925a9413a',
						ShowNo: 4,
						OwnerCode: 'f32950c9-9576-469f-b2c4-b001a2f68be0',
						DownloadFlag: 0,
						DiscussStatus: 0,
						ReviewFlag: 0,
						StudentFlag: 0,
						ReviewStatus: 0,
						ReviewMark: null,
						WenBenFlag: 0,
						KongFlag: 0,
						LianJieFlag: 0,
						TuPianFlag: 0,
						KeJianFlag: 0,
						ShiPinFlag: 0,
						UserName: null,
						PostTime: '2019-05-10T16:02:02Z',
						ExtOne: 0,
						ExtTwo: 0,
						CoResourceView: [
							{
								ResourceCode: '7cfb7d38-3ce7-4f55-acdd-37a484eefb01',
								ResourceName: 'Android智能手机编程\\AndroidManifest.xml项目配置文件',
								ResourceType: 'thirdparty',
								Content: 'odata',
								DownloadCode: 'CVVDDZXX201812000209|CVVD201905|CVED',
								XmlCode: 'CVED',
								XMLFragmentationCode: null,
								ModuleCode: 'a124c46d-ec1e-41be-a841-616d7290b8de',
								ModuleName: null,
								ExtType: null,
								CourseCode: 'a27e86db-4661-4d5e-8fc4-48b25bdd638b',
								UserId: '0f79635f-80c0-4a6e-a634-30b925a9413a',
								RealName: null,
								UserName: null,
								SubmitUserName: '熊凡',
								DiscussStatus: 0,
								DiscussId: null,
								LiveDiscussLink: null,
								LiveDiscussStatus: 0,
								LiveDiscussId: null,
								DiscussLink: null,
								ReviewFlag: 0,
								ReviewFlagHanZi: null,
								ReviewMark: null,
								PostTime: '2019-07-31T17:14:06Z',
								DownloadLink: null,
								FileType: 0,
								CatalogHtml: null,
								Extension: null,
								ReviewFlagShu: 0,
								ZiYuanZongShu: 0,
								ResourceTypeShu: 0,
								LiteratureID: null,
								IsPublic: 0,
								MiniDiscussList: null,
								Exercise: null,
								CataLogName: null,
								Stage: null,
								SubjectName: null,
								CourseVersion: null,
								CourseName: null,
								IsMy: 0,
								IsCNKI: 1,
								AddSource: 1,
								Link: 'http://cved.cnki.net/video/Detail/CVVDDZXX201812000209',
								FileSize: null,
								IsTencent: 0,
								ShowNo: 0,
								InitialResourceName: null,
								HasArranged: false,
								IsRead: 1,
								IsDownLoad: 0,
								Synthesis: 2
							}
						],
						CoHomeWorks: null,
						Content: null,
						ResourceCode: null,
						ContentFlag: 0,
						HomeworkSubmitFlag: 0,
						Introduction: null,
						StudentWork: null,
						CanDelete: 0,
						ResourceCount: 0,
						PModuleCode: null
					},
					{
						ModuleCode: '5b471da6-ad4d-424d-a613-04c6790b0ea2',
						ModuleName: '习题作业',
						CourseCode: 'a27e86db-4661-4d5e-8fc4-48b25bdd638b',
						ModuleType: '作业/测试类',
						UserId: '0f79635f-80c0-4a6e-a634-30b925a9413a',
						ShowNo: 5,
						OwnerCode: 'f32950c9-9576-469f-b2c4-b001a2f68be0',
						DownloadFlag: 0,
						DiscussStatus: 0,
						ReviewFlag: 0,
						StudentFlag: 0,
						ReviewStatus: 0,
						ReviewMark: null,
						WenBenFlag: 0,
						KongFlag: 0,
						LianJieFlag: 0,
						TuPianFlag: 0,
						KeJianFlag: 0,
						ShiPinFlag: 0,
						UserName: null,
						PostTime: '2019-05-10T16:02:02Z',
						ExtOne: 0,
						ExtTwo: 0,
						CoResourceView: [
							{
								ResourceCode: 'a42413d1-1b62-45d3-9c1d-7f626b365379',
								ResourceName: 'maven简介_习题作业',
								ResourceType: '作业/测试类',
								Content: null,
								DownloadCode: null,
								XmlCode: null,
								XMLFragmentationCode: null,
								ModuleCode: '5b471da6-ad4d-424d-a613-04c6790b0ea2',
								ModuleName: '习题作业',
								ExtType: null,
								CourseCode: null,
								UserId: '0f79635f-80c0-4a6e-a634-30b925a9413a',
								RealName: '熊凡',
								UserName: null,
								SubmitUserName: null,
								DiscussStatus: 0,
								DiscussId: null,
								LiveDiscussLink: null,
								LiveDiscussStatus: 0,
								LiveDiscussId: null,
								DiscussLink: null,
								ReviewFlag: 0,
								ReviewFlagHanZi: null,
								ReviewMark: null,
								PostTime: '2019-05-10T16:02:02Z',
								DownloadLink: null,
								FileType: 0,
								CatalogHtml: null,
								Extension: null,
								ReviewFlagShu: 0,
								ZiYuanZongShu: 0,
								ResourceTypeShu: 0,
								LiteratureID: null,
								IsPublic: 0,
								MiniDiscussList: null,
								Exercise: null,
								CataLogName: null,
								Stage: null,
								SubjectName: null,
								CourseVersion: null,
								CourseName: null,
								IsMy: 0,
								IsCNKI: 0,
								AddSource: 0,
								Link: null,
								FileSize: null,
								IsTencent: 0,
								ShowNo: 0,
								InitialResourceName: null,
								HasArranged: false,
								IsRead: 0,
								IsDownLoad: 0,
								Synthesis: 0
							},
							{
								ResourceCode: 'ecdc7025-5a68-436e-b371-b8728287798a',
								ResourceName: 'maven简介_习题作业',
								ResourceType: '作业/测试类',
								Content: null,
								DownloadCode: null,
								XmlCode: null,
								XMLFragmentationCode: null,
								ModuleCode: '5b471da6-ad4d-424d-a613-04c6790b0ea2',
								ModuleName: '习题作业',
								ExtType: null,
								CourseCode: null,
								UserId: '0f79635f-80c0-4a6e-a634-30b925a9413a',
								RealName: '熊凡',
								UserName: null,
								SubmitUserName: null,
								DiscussStatus: 0,
								DiscussId: null,
								LiveDiscussLink: null,
								LiveDiscussStatus: 0,
								LiveDiscussId: null,
								DiscussLink: null,
								ReviewFlag: 0,
								ReviewFlagHanZi: null,
								ReviewMark: null,
								PostTime: '2019-05-10T16:02:02Z',
								DownloadLink: null,
								FileType: 0,
								CatalogHtml: null,
								Extension: null,
								ReviewFlagShu: 0,
								ZiYuanZongShu: 0,
								ResourceTypeShu: 0,
								LiteratureID: null,
								IsPublic: 0,
								MiniDiscussList: null,
								Exercise: null,
								CataLogName: null,
								Stage: null,
								SubjectName: null,
								CourseVersion: null,
								CourseName: null,
								IsMy: 0,
								IsCNKI: 0,
								AddSource: 0,
								Link: null,
								FileSize: null,
								IsTencent: 0,
								ShowNo: 0,
								InitialResourceName: null,
								HasArranged: false,
								IsRead: 0,
								IsDownLoad: 0,
								Synthesis: 0
							}
						],
						CoHomeWorks: null,
						Content: null,
						ResourceCode: null,
						ContentFlag: 0,
						HomeworkSubmitFlag: 0,
						Introduction: null,
						StudentWork: null,
						CanDelete: 0,
						ResourceCount: 0,
						PModuleCode: '0'
					}
				],
				Error: '获取数据成功！',
				Other: null,
				IsMult: false,
				Ext: null,
				Extension: null,
				Total: 0
			};

			// 将 isOfflineSaved 设置为false

			r.Data.forEach(e1 => {
				e1.CoResourceView.forEach(e => {
					e.isOfflineSaved = false;
				});
			});

			this.list_modules = r.Data;
		}
	}
};
</script>

<style></style>
